# CR7 BetBot

CR7 BetBot provides match predictions for EPL, Serie A, and La Liga.

## Features
- Predicts match winner (1X2)
- Predicts Over/Under 2.5 goals
- Covers EPL, Serie A, and La Liga
- Simple interface for mobile use

## Usage
Open the provided link on your phone to access the bot.

## Language
English
