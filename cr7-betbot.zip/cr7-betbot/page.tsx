
import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const mockPredictions = [
  {
    league: "EPL",
    matches: [
      {
        home: "Arsenal",
        away: "Man City",
        prediction: "Home Win | Over 2.5",
      },
      {
        home: "Chelsea",
        away: "Liverpool",
        prediction: "Draw | Under 2.5",
      },
    ],
  },
  {
    league: "La Liga",
    matches: [
      {
        home: "Real Madrid",
        away: "Atletico Madrid",
        prediction: "Home Win | Over 2.5",
      },
      {
        home: "Barcelona",
        away: "Sevilla",
        prediction: "Home Win | Under 2.5",
      },
    ],
  },
  {
    league: "Serie A",
    matches: [
      {
        home: "Juventus",
        away: "AC Milan",
        prediction: "Away Win | Over 2.5",
      },
      {
        home: "Napoli",
        away: "Roma",
        prediction: "Draw | Under 2.5",
      },
    ],
  },
];

export default function Cr7BetBot() {
  const [league, setLeague] = useState("EPL");
  const [predictions, setPredictions] = useState([]);

  useEffect(() => {
    const data = mockPredictions.find((l) => l.league === league);
    setPredictions(data ? data.matches : []);
  }, [league]);

  return (
    <div className="p-4 max-w-2xl mx-auto">
      <div className="text-center mb-4">
        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/72/CR7_logo.svg/512px-CR7_logo.svg.png" alt="CR7 Logo" className="w-20 mx-auto mb-2" />
        <h1 className="text-2xl font-bold">CR7 BetBot - Weekly Predictions</h1>
      </div>

      <div className="flex justify-center gap-2 mb-4">
        {mockPredictions.map((l) => (
          <Button key={l.league} onClick={() => setLeague(l.league)}>
            {l.league}
          </Button>
        ))}
      </div>

      {predictions.map((match, idx) => (
        <Card key={idx} className="mb-2">
          <CardContent className="p-4">
            <div className="font-semibold">{match.home} vs {match.away}</div>
            <div className="text-gray-600">Prediction: {match.prediction}</div>
          </CardContent>
        </Card>
      ))}

      <div className="mt-8 text-center text-sm text-gray-500">
        Contact support via WhatsApp: <a href="https://wa.me/255659355850" className="text-blue-500">+255659355850</a>
      </div>
    </div>
  );
}
